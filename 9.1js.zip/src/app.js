import React from 'react';

function App() {
  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif', textAlign: 'center' }}>
      <h1>React App Served by Nginx in Docker! 🐳</h1>
      <p>This is a production-ready container.</p>
    </div>
  );
}

export default App;